import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  profilePic: text("profile_pic"),
  relationshipStatus: text("relationship_status").default("single"),
  citizenship: text("citizenship"),
  searchable: boolean("searchable").default(true),
  citizenshipSearchable: boolean("citizenship_searchable").default(true),
});

export const relationships = pgTable("relationships", {
  id: serial("id").primaryKey(),
  userId1: integer("user_id_1").notNull(),
  userId2: integer("user_id_2").notNull(),
  status: text("status").notNull().default("pending"), // pending, active, ended
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
});

export const milestones = pgTable("milestones", {
  id: serial("id").primaryKey(),
  relationshipId: integer("relationship_id").notNull(),
  title: text("title").notNull(),
  date: timestamp("date").notNull(),
  description: text("description"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
  profilePic: true,
  relationshipStatus: true,
  citizenship: true,
  searchable: true,
  citizenshipSearchable: true,
});

export const insertRelationshipSchema = createInsertSchema(relationships);
export const insertMilestoneSchema = createInsertSchema(milestones);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Relationship = typeof relationships.$inferSelect;
export type Milestone = typeof milestones.$inferSelect;

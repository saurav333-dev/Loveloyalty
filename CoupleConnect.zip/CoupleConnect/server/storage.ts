import { User, InsertUser, Relationship, Milestone } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  
  // Relationship operations
  createRelationship(userId1: number, userId2: number): Promise<Relationship>;
  getRelationship(id: number): Promise<Relationship | undefined>;
  updateRelationshipStatus(id: number, status: string): Promise<Relationship>;
  getUserRelationships(userId: number): Promise<Relationship[]>;
  
  // Milestone operations
  createMilestone(milestone: Milestone): Promise<Milestone>;
  getMilestones(relationshipId: number): Promise<Milestone[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private relationships: Map<number, Relationship>;
  private milestones: Map<number, Milestone>;
  sessionStore: session.Store;
  private currentId: number;
  private relationshipId: number;
  private milestoneId: number;

  constructor() {
    this.users = new Map();
    this.relationships = new Map();
    this.milestones = new Map();
    this.currentId = 1;
    this.relationshipId = 1;
    this.milestoneId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("User not found");
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createRelationship(userId1: number, userId2: number): Promise<Relationship> {
    const relationship: Relationship = {
      id: this.relationshipId++,
      userId1,
      userId2,
      status: "pending",
      startDate: new Date(),
      endDate: null,
    };
    this.relationships.set(relationship.id, relationship);
    return relationship;
  }

  async getRelationship(id: number): Promise<Relationship | undefined> {
    return this.relationships.get(id);
  }

  async updateRelationshipStatus(id: number, status: string): Promise<Relationship> {
    const relationship = await this.getRelationship(id);
    if (!relationship) throw new Error("Relationship not found");
    const updatedRelationship = { ...relationship, status };
    this.relationships.set(id, updatedRelationship);
    return updatedRelationship;
  }

  async getUserRelationships(userId: number): Promise<Relationship[]> {
    return Array.from(this.relationships.values()).filter(
      (rel) => rel.userId1 === userId || rel.userId2 === userId
    );
  }

  async createMilestone(milestone: Milestone): Promise<Milestone> {
    const id = this.milestoneId++;
    const newMilestone = { ...milestone, id };
    this.milestones.set(id, newMilestone);
    return newMilestone;
  }

  async getMilestones(relationshipId: number): Promise<Milestone[]> {
    return Array.from(this.milestones.values()).filter(
      (milestone) => milestone.relationshipId === relationshipId
    );
  }
}

export const storage = new MemStorage();

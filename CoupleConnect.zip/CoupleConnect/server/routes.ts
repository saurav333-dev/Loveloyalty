import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // User routes
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const relationships = await storage.getUserRelationships(req.user.id);
    res.json(relationships);
  });

  app.patch("/api/users/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.params.id !== req.user.id.toString()) return res.sendStatus(403);
    const user = await storage.updateUser(req.user.id, req.body);
    res.json(user);
  });

  app.post("/api/users/:id/change-password", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.params.id !== req.user.id.toString()) return res.sendStatus(403);

    const { currentPassword, newPassword } = req.body;
    const user = await storage.getUserByUsername(req.user.username);

    if (!user || !(await comparePasswords(currentPassword, user.password))) {
      return res.status(400).send("Current password is incorrect");
    }

    const hashedPassword = await hashPassword(newPassword);
    const updatedUser = await storage.updateUser(req.user.id, {
      password: hashedPassword,
    });

    res.json(updatedUser);
  });


  // Relationship routes
  app.post("/api/relationships", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const relationship = await storage.createRelationship(
      req.user.id,
      parseInt(req.body.userId)
    );
    res.status(201).json(relationship);
  });

  app.patch("/api/relationships/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const relationship = await storage.getRelationship(parseInt(req.params.id));
    if (!relationship) return res.sendStatus(404);
    if (relationship.userId1 !== req.user.id && relationship.userId2 !== req.user.id) {
      return res.sendStatus(403);
    }
    const updated = await storage.updateRelationshipStatus(
      parseInt(req.params.id),
      req.body.status
    );
    res.json(updated);
  });

  // Milestone routes
  app.post("/api/relationships/:id/milestones", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const relationship = await storage.getRelationship(parseInt(req.params.id));
    if (!relationship) return res.sendStatus(404);
    if (relationship.userId1 !== req.user.id && relationship.userId2 !== req.user.id) {
      return res.sendStatus(403);
    }
    const milestone = await storage.createMilestone({
      ...req.body,
      relationshipId: parseInt(req.params.id),
    });
    res.status(201).json(milestone);
  });

  app.get("/api/relationships/:id/milestones", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const relationship = await storage.getRelationship(parseInt(req.params.id));
    if (!relationship) return res.sendStatus(404);
    if (relationship.userId1 !== req.user.id && relationship.userId2 !== req.user.id) {
      return res.sendStatus(403);
    }
    const milestones = await storage.getMilestones(parseInt(req.params.id));
    res.json(milestones);
  });

  const httpServer = createServer(app);
  return httpServer;
}
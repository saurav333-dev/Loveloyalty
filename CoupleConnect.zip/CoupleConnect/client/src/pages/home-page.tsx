import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Relationship, Milestone } from "@shared/schema";
import { Link } from "wouter";
import { Heart, Award, Calendar as CalendarIcon, Clock, ArrowRight, ChartBar } from "lucide-react";
import { format } from "date-fns";

export default function HomePage() {
  const { user } = useAuth();

  const { data: relationships } = useQuery<Relationship[]>({
    queryKey: ["/api/users"],
  });

  const activeRelationship = relationships?.find(r => r.status === "active");

  const { data: milestones } = useQuery<Milestone[]>({
    queryKey: ["/api/relationships", activeRelationship?.id, "milestones"],
    enabled: !!activeRelationship,
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-6">
        <div className="container">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Welcome, {user?.name}</h1>
            <div className="flex gap-2">
              <Link href="/dashboard">
                <Button variant="secondary">
                  <ChartBar className="w-4 h-4 mr-2" />
                  Analytics
                </Button>
              </Link>
              <Link href="/profile">
                <Button variant="secondary">Profile Settings</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="text-primary" />
                Relationship Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              {activeRelationship ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <img
                      src="https://images.unsplash.com/photo-1499568509606-4f9b771232ed"
                      alt="Couple"
                      className="w-20 h-20 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-medium">In a relationship</p>
                      <p className="text-sm text-muted-foreground">
                        Since {format(new Date(activeRelationship.startDate!), 'MMMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">No active relationship</p>
                  <Button variant="outline" className="mt-4">
                    Find Partner
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="text-primary" />
                Milestones
              </CardTitle>
            </CardHeader>
            <CardContent>
              {milestones && milestones.length > 0 ? (
                <div className="space-y-4">
                  {milestones.map((milestone) => (
                    <div
                      key={milestone.id}
                      className="flex items-center gap-4 p-4 rounded-lg bg-accent/10"
                    >
                      <div className="h-12 w-12 rounded-full bg-accent flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-medium">{milestone.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(milestone.date), 'MMMM d, yyyy')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground">No milestones yet</p>
                  {activeRelationship && (
                    <Button variant="outline" className="mt-4">
                      Add Milestone
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="text-primary" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {[
                  "https://images.unsplash.com/photo-1531747056595-07f6cbbe10ad",
                  "https://images.unsplash.com/photo-1579208570378-8c970854bc23",
                  "https://images.unsplash.com/photo-1541089404510-5c9a779841fc"
                ].map((src, i) => (
                  <div key={i} className="relative group">
                    <img
                      src={src}
                      alt="Activity"
                      className="w-full aspect-square object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button variant="secondary" size="sm">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
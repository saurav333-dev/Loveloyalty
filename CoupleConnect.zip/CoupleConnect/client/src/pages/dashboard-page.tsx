import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Relationship, Milestone } from "@shared/schema";
import { Link } from "wouter";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { format, differenceInDays, differenceInMonths, differenceInYears } from "date-fns";
import { CalendarDays, Heart, Award, TrendingUp } from "lucide-react";

const COLORS = ['#FF4B6E', '#FF8FA3', '#6C63FF', '#FFF5F6'];

export default function DashboardPage() {
  const { user } = useAuth();

  const { data: relationships } = useQuery<Relationship[]>({
    queryKey: ["/api/users"],
  });

  const activeRelationship = relationships?.find(r => r.status === "active");

  const { data: milestones } = useQuery<Milestone[]>({
    queryKey: ["/api/relationships", activeRelationship?.id, "milestones"],
    enabled: !!activeRelationship,
  });

  const calculateDuration = () => {
    if (!activeRelationship?.startDate) return { days: 0, months: 0, years: 0 };
    const start = new Date(activeRelationship.startDate);
    const now = new Date();
    return {
      days: differenceInDays(now, start),
      months: differenceInMonths(now, start),
      years: differenceInYears(now, start),
    };
  };

  const duration = calculateDuration();
  
  const milestonesByMonth = milestones?.reduce((acc: any, milestone) => {
    const month = format(new Date(milestone.date), 'MMM yyyy');
    acc[month] = (acc[month] || 0) + 1;
    return acc;
  }, {});

  const milestoneChartData = Object.entries(milestonesByMonth || {}).map(([month, count]) => ({
    month,
    count,
  }));

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground py-6">
        <div className="container">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Relationship Analytics</h1>
            <Link href="/">
              <Button variant="secondary">Back to Home</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="text-primary" />
                Relationship Duration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="p-4 rounded-lg bg-primary/10">
                  <p className="text-3xl font-bold text-primary">{duration.years}</p>
                  <p className="text-sm text-muted-foreground">Years</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10">
                  <p className="text-3xl font-bold text-primary">{duration.months % 12}</p>
                  <p className="text-sm text-muted-foreground">Months</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10">
                  <p className="text-3xl font-bold text-primary">{duration.days % 30}</p>
                  <p className="text-sm text-muted-foreground">Days</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="text-primary" />
                Milestone Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={milestoneChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#FF4B6E" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="text-primary" />
                Relationship Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {milestones?.sort((a, b) => 
                  new Date(b.date).getTime() - new Date(a.date).getTime()
                ).map((milestone) => (
                  <div key={milestone.id} className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <CalendarDays className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">{milestone.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {format(new Date(milestone.date), 'MMMM d, yyyy')}
                      </p>
                      {milestone.description && (
                        <p className="mt-1 text-sm text-muted-foreground">
                          {milestone.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}

                {!milestones?.length && (
                  <div className="text-center py-6">
                    <p className="text-muted-foreground">No milestones recorded yet</p>
                    <Button variant="outline" className="mt-4">
                      Add Your First Milestone
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="text-center py-6 text-sm text-muted-foreground">
        <p>Developed with ❤️ by Lucifer</p>
      </footer>
    </div>
  );
}

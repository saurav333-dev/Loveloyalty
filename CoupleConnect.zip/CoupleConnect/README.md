# LoyaltyLove - Relationship Management Platform

A privacy-focused relationship management platform designed to enhance couple communication and connection.

## Features

- User authentication with secure password management
- Profile management with privacy settings
- Unique ID system for partner connections
- Relationship analytics dashboard
- Milestone tracking
- Privacy-focused design

## Tech Stack

- React + TypeScript (Frontend)
- Express.js (Backend)
- TanStack Query for data fetching
- Shadcn/UI + Tailwind CSS for styling
- Recharts for analytics visualizations

## Setup Instructions

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Environment Variables

Create a `.env` file in the root directory with:

```
SESSION_SECRET=your_session_secret
```

## Project Structure

```
├── client/              # Frontend React application
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── hooks/      # Custom React hooks
│   │   ├── lib/        # Utility functions
│   │   └── pages/      # Application pages
├── server/             # Backend Express application
│   ├── auth.ts        # Authentication logic
│   ├── routes.ts      # API routes
│   └── storage.ts     # Data storage interface
└── shared/            # Shared types and schemas
```

## Development

- Frontend code is in the `client` directory
- Backend API routes are in `server/routes.ts`
- Shared types and schemas are in `shared/schema.ts`

## License

MIT

## Author

Developed with ❤️ by Lucifer
